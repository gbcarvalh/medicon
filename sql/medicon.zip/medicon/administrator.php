<!DOCTYPE html>
<html lang="pt-br">

<head>
	<title>Administrador</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="Health medical template project">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
	<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="styles/contact.css">
	<link rel="stylesheet" type="text/css" href="styles/contact_responsive.css">
</head>

<body>

	<div class="super_container">

		<!-- Menu -->

		<div class="menu trans_500">
			<div class="menu_content d-flex flex-column align-items-center justify-content-center text-center">
				<div class="menu_close_container">
					<div class="menu_close"></div>
				</div>
				<form action="#" class="menu_search_form">
					<input type="text" class="menu_search_input" placeholder="Search" required="required">
					<button class="menu_search_button"><i class="fa fa-search" aria-hidden="true"></i></button>
				</form>
				<ul>
					<li class="menu_item"><a href="index.php">Início</a></li>
					<li class="menu_item"><a href="#.php">Em breve</a></li>
					<li class="menu_item"><a href="#.php">Em breve</a></li>
					<li class="menu_item"><a href="search_doctor.php">Encontre seu médico</a></li>
					<li class="menu_item"><a href="administrator.php">Administrador</a></li>
				</ul>
			</div>
			<div class="menu_social">
				<ul>
					<li><a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-behance" aria-hidden="true"></i></a></li>
					<li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
				</ul>
			</div>
		</div>

		<!-- Home -->

		<div class="home">
			<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/contact.jpg" data-speed="0.8"></div>

			<!-- Header -->

			<header class="header" id="header">
				<div>
					<div class="header_top">
						<div class="container">
							<div class="row">
								<div class="col">
									<div class="header_top_content d-flex flex-row align-items-center justify-content-start">
										<div class="logo">
											<a href="#">Medicon<span>+</span></a>
										</div>
										<div class="header_top_extra d-flex flex-row align-items-center justify-content-start ml-auto">
											<div class="header_top_nav">
												<ul class="d-flex flex-row align-items-center justify-content-start">
													<li><a href="#">IFSULDEMINAS</a></li>
													<li><a href="#">Os empreendedores</a></li>
												</ul>
											</div>
											<div class="header_top_phone">
												<i class="fa fa-phone" aria-hidden="true"></i>
												<span>+55 35 3427-6600</span>
											</div>
										</div>
										<div class="hamburger ml-auto"><i class="fa fa-bars" aria-hidden="true"></i></div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="header_nav" id="header_nav_pin">
						<div class="header_nav_inner">
							<div class="header_nav_container">
								<div class="container">
									<div class="row">
										<div class="col">
											<div class="header_nav_content d-flex flex-row align-items-center justify-content-start">
												<nav class="main_nav">
													<ul class="d-flex flex-row align-items-center justify-content-start">
														<li class="menu_item"><a href="index.php">Início</a></li>
														<li class="menu_item"><a href="#.php">Em breve</a></li>
														<li class="menu_item"><a href="#.php">Em breve</a></li>
														<li class="menu_item"><a href="search_doctor.php">Encontre seu médico</a></li>
														<li class="menu_item"><a href="administrator.php">Administrador</a></li>
													</ul>
												</nav>
												<div class="search_content d-flex flex-row align-items-center justify-content-end ml-auto">
													<form action="#" id="search_container_form" class="search_container_form">
														<input type="text" class="search_container_input" placeholder="Search" required="required">
														<button class="search_container_button"><i class="fa fa-search" aria-hidden="true"></i></button>
													</form>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header>

			<div class="home_container">
				<div class="container">
					<div class="row">
						<div class="col">
							<div class="home_content">
								<div class="home_title">Administrador</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Contact -->

		<div class="contact">
			<div class="container">
				<div class="row">


					<div class="panel-group" style="width: 30%; margin: 1em; padding: 1.5em 1em; border: 1px solid #aaaaaa; border-radius: 4px; background-color: #1b7694;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title" style="text-align: center">
									<a data-toggle="collapse" href="#collapse1" style="text-decoration:none; color: #ffffff; text-style: center;">Médico</a>
								</h4>
							</div>
							<div id="collapse1" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><a href="register_doctor.php" style="text-decoration:none; color: black; text-style: center;">Cadastrar</a></li>
									<li class="list-group-item"><a href="search_doctor.php" style="text-decoration:none; color: black; text-style: center;">Pesquisar</a></li>
								</ul>
							</div>
						</div>
					</div>

					<div class="panel-group" style="width: 30%; margin: 1em; padding: 1.5em 1em; border: 1px solid #aaaaaa; border-radius: 4px; background-color: #1b7694;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title" style="text-align: center">
									<a data-toggle="collapse" href="#collapse2" style="text-decoration:none; color: #ffffff; text-style: center;">Paciente</a>
								</h4>
							</div>
							<div id="collapse2" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><a href="register_patient.php" style="text-decoration:none; color: black; text-style: center;">Cadastrar</a></li>
									<li class="list-group-item"><a href="search_patient.php" style="text-decoration:none; color: black; text-style: center;">Pesquisar</a></li>
								</ul>
							</div>
						</div>
					</div>

					<div class="panel-group" style="width: 30%; margin: 1em; padding: 1.5em 1em; border: 1px solid #aaaaaa; border-radius: 4px; background-color: #1b7694;">
						<div class="panel panel-default">
							<div class="panel-heading">
								<h4 class="panel-title" style="text-align: center">
									<a data-toggle="collapse" href="#collapse3" style="text-decoration:none; color: #ffffff; text-style: center;">Convênio</a>
								</h4>
							</div>
							<div id="collapse3" class="panel-collapse collapse">
								<ul class="list-group">
									<li class="list-group-item"><a href="register_plan.php" style="text-decoration:none; color: black; text-style: center;">Cadastrar</a></li>
									<li class="list-group-item"><a href="search_plan.php" style="text-decoration:none; color: black; text-style: center;">Pesquisar</a></li>
								</ul>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>



		<!-- Footer -->

		<footer class="footer">
			<div class="parallax_background parallax-window" data-parallax="scroll" data-image-src="images/footer.jpg" data-speed="0.8"></div>
			<div class="footer_content">
				<div class="container">
					<div class="row">

						
						
					</div>
				</div>
			</div>
			<div class="footer_bar">
				<div class="container">
					<div class="row">
						<div class='col'>
							<div class="footer_bar_content d-flex flex-sm-row flex-column align-items-lg-center align-items-start justify-content-start">
								<nav class="footer_nav">
									<ul class="d-flex flex-lg-row flex-column align-items-lg-center align-items-start justify-content-start">
										<li class="active"><a href="index.html">Home</a></li>
										<li><a href="about.html">About Us</a></li>
										<li><a href="services.html">Services</a></li>
										<li><a href="news.html">News</a></li>
										<li><a href="contact.html">Contact</a></li>
									</ul>
								</nav>
								<div class="footer_links">
									<ul class="d-flex flex-lg-row flex-column align-items-lg-center align-items-start justify-content-start">
										<li><a href="#">Help Desk</a></li>
										<li><a href="#">Emergency Services</a></li>
										<li><a href="#">Appointment</a></li>
									</ul>
								</div>
								<div class="footer_phone ml-lg-auto">
									<i class="fa fa-phone" aria-hidden="true"></i>
									<span>+34 586 778 8892</span>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
	</div>

	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="styles/bootstrap4/popper.js"></script>
	<script src="styles/bootstrap4/bootstrap.min.js"></script>
	<script src="plugins/easing/easing.js"></script>
	<script src="plugins/parallax-js-master/parallax.min.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?v=3.exp&key=AIzaSyCIwF204lFZg1y4kPSIhKaHEXMLYxxuMhA"></script>
	<script src="js/contact.js"></script>
</body>

</html>